document.getElementById('send').onclick = async () => {
  const prompt = document.getElementById('prompt').value;
  const responseEl = document.getElementById('response');
  responseEl.textContent = 'Warte auf Antwort...';

  try {
    const res = await fetch('/api/ai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt })
    });
    const data = await res.json();
    responseEl.textContent = data?.result || 'Keine Antwort erhalten.';
  } catch (err) {
    responseEl.textContent = 'Fehler: ' + err.message;
  }
};